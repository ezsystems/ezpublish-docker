Copy sahi.syn to <TextPad_Install_dir>/system

Add sahi.syn as the syntax file for .sah files:
Go to "Configure"->"New Document Class ..."
Document class name: Sahi
Next
Class members: *.sah
Next
Enable Syntax Highlighting (check this)
Syntax definition file: choose sahi.syn
Next
Finish

If you want the clip library too,
Copy sahi.TCL to C:\Documents and Settings\<UserName>\Application Data\TextPad

Restart textpad.
