For Autocomplete
----------------
1) Copy plugin/APIs/sahi.xml to Notepad++/plugin/APIs/ 


For Syntax highlighting
-----------------------
1) Go to View -> User-Defined Dialogue
2) Click Import
3) Choose sahi_syn.xml 
4) Restart Notepad++
