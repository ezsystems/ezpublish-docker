Sahi Nightly Release @build@

Sahi uses Rhino as its javascript engine. Rhino is open source.
Go to https://developer.mozilla.org/en/Rhino_License for information on Rhino's licensing.
 
Documentation in this directory is not current.
Please visit http://sahi.co.in/ for the latest documentation.