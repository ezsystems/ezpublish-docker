The paths of sahi.jar and sahi-ant.jar need to be set correctly in the sample files.
