# Set default properties here. These values will be used only if not overriden in <username>_props.rb
SAHI_DIR = 'C:\\projects\\your_app\\test\\sahi'
SAHI_SCRIPTS_DIR = "#{SAHI_DIR}\\scripts"
SAHI_TEST_SUITE = "your_app.suite"
IE = 'C:\\Program Files\\Internet Explorer\\IEXPLORE.EXE'
IE_EXE = 'IEXPLORE.EXE'
IE_OPTIONS = ''
FIREFOX = "C:\\Program Files\\Mozilla Firefox\\firefox.exe"
FIREFOX_EXE = 'firefox.exe'
FIREFOX_OPTIONS = '-profile ../browser/ff/profiles/sahi$threadNo -no-remote'
START_URL = 'http://localhost:3000/'
