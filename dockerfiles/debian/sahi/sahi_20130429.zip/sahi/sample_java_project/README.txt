1) Copy sahi/lib/sahi.jar to sample_java_project/lib/sahi.jar
2) Import this project into Eclipse
3) Add sahi.jar to the classpath
4) For Internet Explorer, make sure you have set the proxy settings to localhost:9999
5) Start Sahi's proxy using sahi/userdata/bin/start_sahi.bat
6) Run JavaClientTest as a JUnit testcase
