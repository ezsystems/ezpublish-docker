For browsers without XPath support, use Javascript-XPath: (http://coderepos.org/share/wiki/JavaScript-XPath)
Copy the contents from 
http://svn.coderepos.org/share/lang/javascript/javascript-xpath/trunk/release/javascript-xpath-latest.js 
and save it in a file with name javascript-xpath.js in this same directory

Sahi will look for this file at spr/ext/javascript-xpath/javascript-xpath.js

This file is under its own MIT license and is not part of Sahi's code base