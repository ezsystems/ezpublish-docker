<?php
sleep(40);
?>
<div>Hi there!</div>
