Sahi Ruby extension
-------------------

Download Sahi from http://sahi.co.in/
Discuss in the Sahi Forums: http://sahi.co.in/forums
Join the LinkedIn Group: http://www.linkedin.com/groups?home=&gid=989367
Follow on twitter: http://www.twitter.com/_sahi