These jars are required for building:
extlib/test/ant-launcher.jar
extlib/test/jmock-1.1.0.jar
extlib/test/ant-testutil.jar
extlib/test/jmock-cglib-1.1.0.jar
extlib/xmlrpc/xmlrpc-common-3.0.jar
extlib/xmlrpc/xmlrpc-client-3.0.jar
extlib/xmlrpc/ws-commons-util-1.0.1.jar
extlib/test/cglib-nodep-2.1_3.jar
extlib/test/junit.jar
extlib/test/log4j.jar

You can also download them from the web:

JavaMail: http://java.sun.com/products/javamail/javamail-1_4.html
XMLRPC:   http://www.apache.org/dyn/closer.cgi/ws/xmlrpc/
Ant:      http://ant.apache.org/bindownload.cgi
JMock:    http://www.jmock.org/download.html
JUnit:    http://www.junit.org/
log4j:    http://logging.apache.org/log4j/1.2/download.html